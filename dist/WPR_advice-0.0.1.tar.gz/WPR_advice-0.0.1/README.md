# Analysis with William's Percent Range (WPR)

Description. 
The package William's Percent Range is used to:
- Processing:
    - Download data
    - Updata data
    - Processing Model

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install WPR_advice

```bash
pip install WPR_advice
```

## Usage

```python
from WPR_advice import Download_data
Download_data.Coleta()
```

## Author
Milson Fortunato Neto

## License
[MIT](https://choosealicense.com/licenses/mit/)